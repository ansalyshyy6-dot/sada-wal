package com.sada.walkie

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.NoiseSuppressor
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tanh
import kotlin.random.Random

private const val PORT = 40123
private const val RATE = 16000
private const val FRAME = 320            // 20ms من الصوت
private const val HEAD = 11              // [سحر][قناة][نوع][رقم المرسل x4][تسلسل x4]
private const val MAGIC = 0x5A
private const val T_HELLO = 0
private const val T_AUDIO = 1
private const val PREBUF = 3             // عدد الإطارات قبل بدء التشغيل (60ms) لتخفيف التقطيع
private const val MAXQ = 16              // أقصى تأخير مسموح لكل مرسل (320ms)
private const val PRE_MAX = 8            // أقصى عمق لمخزن التأخير التكيفي (160ms)
private const val PEER_TTL = 6000L       // مدة بقاء الجهاز «حياً» بعد آخر حزمة منه
private const val MAX_RED_PEERS = 8      // فوق هذا العدد نوقف إرسال الإطار المكرر لتوفير الهواء
private const val MIC_GAIN = 1.4f
private val GAIN = floatArrayOf(1f, 1.8f, 2.8f, 4f)   // تكبير برمجي حسب مستوى القوة
private val ENH = intArrayOf(0, 300, 600, 900)        // تقوية إضافية من النظام (ملي بل)

/** حد ناعم يمنع التشويه الحاد عند رفع الصوت. المدخل والمخرج بين -1 و 1. */
private fun soft(x: Float): Float {
    val a = abs(x)
    if (a <= 0.6f) return x
    val y = 0.6f + 0.4f * tanh((a - 0.6f) / 0.4f)
    return if (x < 0f) -y else y
}

/**
 * جهاز لاسلكي عبر UDP Broadcast: بدون إنترنت وبدون إعداد.
 * - الإرسال من ميكروفون الهاتف نفسه.
 * - الاستقبال من سماعة الهاتف الخارجية (بصوت مرتفع) مع مخزن تأخير ودمج عدة متحدثين.
 */
class Radio private constructor(private val ctx: Context) {
    companion object {
        @Volatile private var inst: Radio? = null
        fun get(c: Context): Radio =
            inst ?: synchronized(this) { inst ?: Radio(c.applicationContext).also { inst = it } }
    }

    private class Src {
        val q = ArrayDeque<ShortArray>()
        var lastSeq = 0
        var started = false
        var playing = false
        var pre = PREBUF            // عمق المخزن الحالي (يكبر تلقائياً إذا تقطّعت الشبكة)
        var emptyAt = 0L
        var okRun = 0
        @Volatile var last = 0L

        @Synchronized
        fun take(): ShortArray? {
            if (!playing && q.size >= pre) playing = true
            if (!playing) return null
            val f = q.pollFirst()
            if (f == null) {
                playing = false; okRun = 0; emptyAt = System.currentTimeMillis()
            } else if (++okRun >= 500) {          // 10 ثوانٍ بلا انقطاع: صغّر المخزن تدريجياً
                okRun = 0
                if (pre > PREBUF) pre--
            }
            return f
        }
    }

    private val myId = Random.nextInt()
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Volatile var channel = 1
    @Volatile var listen = true
    @Volatile var lastRx = 0L
    @Volatile var phoneAudio = true      // سماعة وميكروفون الهاتف نفسه
    @Volatile var boost = 2              // 0..3
    @Volatile var running = false
        private set
    @Volatile var talking = false
        private set

    @Volatile private var gen = 0
    @Volatile private var targets: List<InetAddress> = emptyList()
    private var seq = 0
    private var sock: DatagramSocket? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private val peersSeen = ConcurrentHashMap<Int, Pair<Int, Long>>()
    // عناوين الأجهزة التي سمعناها مباشرة: نرسل لها الصوت أحادياً (Unicast) لأنه أوثق من البث العام
    private val direct = ConcurrentHashMap<InetAddress, Long>()
    // عناوين أخبرنا بها جهاز آخر (لم نسمعها بعد): نرسل لها «مرحباً» فقط لنتعارف
    private val hints = ConcurrentHashMap<InetAddress, Long>()
    @Volatile private var myAddrs: Set<InetAddress> = emptySet()
    private val srcs = ConcurrentHashMap<Int, Src>()
    private val headsetTypes = setOf(
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_USB_HEADSET
    )

    private fun alive(g: Int) = running && g == gen

    fun peers(): Int {
        val now = System.currentTimeMillis()
        return peersSeen.values.count { it.first == channel && now - it.second < 5000 }
    }

    @Synchronized
    fun start(): Boolean {
        if (running) return true
        return try {
            val wm = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
            mcLock = wm.createMulticastLock("sada-mc").apply { setReferenceCounted(false); acquire() }
            sock = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                soTimeout = 1000
                receiveBufferSize = 256 * 1024
                sendBufferSize = 256 * 1024
                bind(InetSocketAddress(PORT))
            }
            targets = findTargets()
            running = true
            val g = gen
            applyVolume()
            listOf(
                Thread({ receiveLoop(g) }, "sada-rx"),
                Thread({ playLoop(g) }, "sada-play"),
                Thread({ helloLoop(g) }, "sada-hello")
            ).forEach { it.isDaemon = true; it.start() }
            true
        } catch (e: Exception) {
            stop(); false
        }
    }

    @Synchronized
    fun stop() {
        running = false; talking = false
        gen++
        try { sock?.close() } catch (_: Exception) {}
        sock = null
        try { mcLock?.release() } catch (_: Exception) {}
        mcLock = null
        peersSeen.clear(); srcs.clear(); direct.clear(); hints.clear()
    }

    /** إعادة التشغيل بعد تغيّر الشبكة (انضمام لهوتسبوت مثلاً). */
    @Synchronized
    fun restart() {
        if (running) { stop(); start() }
    }

    // ---------- الصوت والمسارات ----------

    private fun headphonesConnected(): Boolean = try {
        audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in headsetTypes }
    } catch (_: Exception) { false }

    /** رفع مستوى وسائط النظام للأقصى عند التشغيل من سماعة الهاتف (إلا في مستوى «عادي»). */
    fun applyVolume() {
        try {
            val toSpeaker = phoneAudio || !headphonesConnected()
            if (boost >= 1 && toSpeaker) {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
            }
        } catch (_: Exception) {}
    }

    private fun route(track: AudioTrack, phone: Boolean) {
        try {
            val dev = if (phone) audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER } else null
            track.setPreferredDevice(dev)
        } catch (_: Exception) {}
    }

    // ---------- الشبكة ----------

    private fun findTargets(): List<InetAddress> {
        val out = mutableListOf<InetAddress>()
        val mine = HashSet<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    mine.add(ia.address)
                    ia.broadcast?.let { out.add(it) }
                }
            }
        } catch (_: Exception) {}
        myAddrs = mine
        if (out.isEmpty()) out.add(InetAddress.getByName("255.255.255.255"))
        return out
    }

    /** بث عام (يُستخدم للتعارف، وللصوت فقط حين لا نعرف أي جهاز بعد). */
    private fun send(buf: ByteArray, len: Int) {
        val s = sock ?: return
        for (t in targets) try { s.send(DatagramPacket(buf, len, t, PORT)) } catch (_: Exception) {}
    }

    private fun sendTo(ip: InetAddress, buf: ByteArray, len: Int) {
        val s = sock ?: return
        try { s.send(DatagramPacket(buf, len, ip, PORT)) } catch (_: Exception) {}
    }

    private fun liveDirect(): Int {
        val now = System.currentTimeMillis()
        return direct.values.count { now - it < PEER_TTL }
    }

    /** الصوت: أحادي لكل جهاز معروف (يُؤكَّد ويُعاد إرساله من طبقة الواي فاي)، وإلا بث عام. */
    private fun sendAudio(buf: ByteArray, len: Int) {
        val now = System.currentTimeMillis()
        var sent = false
        for (e in direct.entries) {
            if (now - e.value < PEER_TTL) { sendTo(e.key, buf, len); sent = true }
        }
        if (!sent) send(buf, len)
    }

    private fun fill(b: ByteArray, type: Int, seqNo: Int) {
        b[0] = MAGIC.toByte(); b[1] = channel.toByte(); b[2] = type.toByte()
        ByteBuffer.wrap(b, 3, 8).putInt(myId).putInt(seqNo)
    }

    /** «مرحباً» = الترويسة + قائمة عناوين الأجهزة التي نسمعها (4 بايت لكل عنوان) ليتعارف الجميع بسرعة. */
    private fun buildHello(): ByteArray {
        val now = System.currentTimeMillis()
        val ips = direct.entries.filter { now - it.value < PEER_TTL }.map { it.key }.take(30)
        val b = ByteArray(HEAD + ips.size * 4)
        fill(b, T_HELLO, 0)
        var o = HEAD
        for (ip in ips) {
            val a = ip.address
            if (a.size == 4) { System.arraycopy(a, 0, b, o, 4); o += 4 }
        }
        return b
    }

    private fun replyHello(ip: InetAddress) {
        val h = buildHello()
        sendTo(ip, h, h.size)
    }

    private fun readGossip(buf: ByteArray, n: Int, now: Long) {
        var o = HEAD
        while (o + 4 <= n) {
            val a = try {
                InetAddress.getByAddress(byteArrayOf(buf[o], buf[o + 1], buf[o + 2], buf[o + 3]))
            } catch (_: Exception) { null }
            o += 4
            if (a != null && a !in myAddrs && !direct.containsKey(a)) hints[a] = now
        }
    }

    private fun helloLoop(g: Int) {
        var tick = 0
        while (alive(g)) {
            targets = findTargets()
            val now = System.currentTimeMillis()
            peersSeen.entries.removeAll { now - it.value.second > 6000 }
            direct.entries.removeAll { now - it.value > PEER_TTL }
            val b = buildHello()
            send(b, b.size)                                  // بث عام للتعارف
            for (ip in direct.keys) sendTo(ip, b, b.size)    // وأحادي للمعروفين (يبقيهم أحياء حتى لو أُسقط البث)
            for (e in hints.entries) {
                if (now - e.value > 10_000L) hints.remove(e.key) else sendTo(e.key, b, b.size)
            }
            tick++
            // أول 10 ثوانٍ: مرحباً كل نصف ثانية لتعارف أسرع، بعدها كل ثانية
            try { Thread.sleep(if (tick < 20) 500L else 1000L) } catch (_: InterruptedException) {}
        }
    }

    private fun receiveLoop(g: Int) {
        val s = sock ?: return
        val buf = ByteArray(2048)
        val pkt = DatagramPacket(buf, buf.size)
        while (alive(g)) {
            try {
                pkt.length = buf.size
                s.receive(pkt)
                val n = pkt.length
                if (n < HEAD || (buf[0].toInt() and 0xFF) != MAGIC) continue
                val bb = ByteBuffer.wrap(buf, 3, 8)
                val id = bb.int
                val sq = bb.int
                if (id == myId) continue
                val ch = buf[1].toInt()
                val type = buf[2].toInt()
                val now = System.currentTimeMillis()
                peersSeen[id] = ch to now
                val from = pkt.address
                if (from != null && from.address.size == 4 && from !in myAddrs) {
                    val isNew = direct.put(from, now) == null
                    hints.remove(from)
                    if (type == T_HELLO) {
                        readGossip(buf, n, now)
                        if (isNew) replyHello(from)          // ردّ فوري على جهاز جديد بدل انتظار الدورة
                    }
                }
                if (type == T_AUDIO && ch == channel && listen && !talking && n > HEAD) {
                    enqueue(id, buf, n, sq, now)
                }
            } catch (_: SocketTimeoutException) {
            } catch (_: Exception) {
                if (!alive(g)) break
                try { Thread.sleep(20) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun enqueue(id: Int, buf: ByteArray, n: Int, sq: Int, now: Long) {
        val samples = (n - HEAD) / 2
        if (samples <= 0) return
        val all = ShortArray(samples)
        ByteBuffer.wrap(buf, HEAD, samples * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(all)
        val s = srcs.getOrPut(id) { Src() }
        synchronized(s) {
            if (samples == FRAME * 2) {
                // حزمة فيها الإطار السابق + الحالي: إن ضاع السابق نسترجعه، وإن وصل يُسقط كمكرر
                push(s, all.copyOfRange(0, FRAME), sq - 1, now)
                push(s, all.copyOfRange(FRAME, FRAME * 2), sq, now)
            } else push(s, all, sq, now)
        }
        lastRx = now
    }

    /** يُستدعى داخل synchronized(s). */
    private fun push(s: Src, f: ShortArray, sq: Int, now: Long) {
        if (s.started) {
            val d = sq - s.lastSeq
            if (d <= 0 && d > -200) return      // حزمة مكررة أو متأخرة
        }
        if (s.emptyAt != 0L) {
            // امتلأ بعد أن فرغ أثناء الكلام (أقل من 300ms) = تقطّع حقيقي، فكبّر المخزن
            if (now - s.emptyAt < 300 && s.pre < PRE_MAX) s.pre++
            s.emptyAt = 0L
        }
        s.started = true
        s.lastSeq = sq
        s.q.addLast(f)
        while (s.q.size > MAXQ) s.q.pollFirst()
        s.last = now
    }

    // ---------- التشغيل: دمج المتحدثين + رفع القوة ----------

    private fun pause(ns: Long) {
        try { Thread.sleep(ns / 1_000_000L, (ns % 1_000_000L).toInt()) } catch (_: InterruptedException) {}
    }

    private fun playLoop(g: Int) {
        val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(minBuf, FRAME * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (_: Exception) { return }

        var enh: LoudnessEnhancer? = null
        try { enh = LoudnessEnhancer(track.audioSessionId).also { it.setEnabled(true) } } catch (_: Throwable) {}

        var routedPhone: Boolean? = null
        var level = -1
        val mix = IntArray(FRAME)
        val out = ShortArray(FRAME)
        val lead = ShortArray(FRAME * 2)      // سكون قصير لبناء هامش أمان قبل بدء الكلام
        var wasIdle = true
        var next = System.nanoTime()
        track.play()

        while (alive(g)) {
            if (routedPhone != phoneAudio) { routedPhone = phoneAudio; route(track, phoneAudio) }
            if (level != boost) {
                level = boost
                try { enh?.setTargetGain(ENH[level.coerceIn(0, 3)]) } catch (_: Throwable) {}
            }
            mix.fill(0)
            var any = false
            val now = System.currentTimeMillis()
            for (e in srcs.entries) {
                val s = e.value
                if (now - s.last > 3000) { srcs.remove(e.key); continue }
                val f = s.take() ?: continue
                val m = min(f.size, FRAME)
                for (i in 0 until m) mix[i] = mix[i] + f[i].toInt()
                any = true
            }
            if (any) {
                if (wasIdle) { track.write(lead, 0, lead.size); wasIdle = false; next = System.nanoTime() }
                val gn = GAIN[boost.coerceIn(0, 3)]
                for (i in 0 until FRAME) out[i] = (soft(mix[i] * gn / 32768f) * 32767f).toInt().toShort()
                track.write(out, 0, FRAME)
                next += 20_000_000L
                val wait = next - System.nanoTime()
                if (wait > 0) pause(wait) else if (wait < -100_000_000L) next = System.nanoTime()
            } else {
                wasIdle = true
                next = System.nanoTime()
                pause(8_000_000L)
            }
        }
        try { track.stop() } catch (_: Exception) {}
        try { track.release() } catch (_: Exception) {}
        try { enh?.release() } catch (_: Exception) {}
    }

    // ---------- الإرسال: ميكروفون الهاتف ----------

    @SuppressLint("MissingPermission")
    fun talk(on: Boolean) {
        if (!on) { talking = false; return }
        if (!running || talking) return
        talking = true
        val g = gen
        Thread({ captureLoop(g) }, "sada-mic").start()
    }

    private fun amplifyMic(b: ByteArray, off: Int, len: Int) {
        var i = off
        val end = off + (len and 1.inv())
        while (i < end) {
            val s = (b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)
            val v = (soft(s * MIC_GAIN / 32768f) * 32767f).toInt()
            b[i] = (v and 0xFF).toByte()
            b[i + 1] = (v shr 8).toByte()
            i += 2
        }
    }

    @SuppressLint("MissingPermission")
    private fun captureLoop(g: Int) {
        var rec: AudioRecord? = null
        val fx = mutableListOf<AudioEffect>()
        try {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) throw IllegalStateException("AudioRecord buffer is unavailable")
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FRAME * 2 * 8)
            )
            rec = r
            if (r.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microphone is unavailable")
            if (phoneAudio) try {
                val mic = audio.getDevices(AudioManager.GET_DEVICES_INPUTS)
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
                if (mic != null) r.setPreferredDevice(mic)
            } catch (_: Exception) {}
            try {
                if (AutomaticGainControl.isAvailable())
                    AutomaticGainControl.create(r.audioSessionId)?.let { it.setEnabled(true); fx.add(it) }
                if (NoiseSuppressor.isAvailable())
                    NoiseSuppressor.create(r.audioSessionId)?.let { it.setEnabled(true); fx.add(it) }
            } catch (_: Throwable) {}

            r.startRecording()
            val cur = ByteArray(FRAME * 2)
            val out = ByteArray(HEAD + FRAME * 4)
            var prev: ByteArray? = null
            while (talking && alive(g)) {
                val n = r.read(cur, 0, cur.size)
                if (n < 0) break
                if (n == 0) continue
                val len = n and 1.inv()
                amplifyMic(cur, 0, len)
                fill(out, T_AUDIO, seq++)
                var o = HEAD
                // إطار احتياطي: نرفق الإطار السابق مع الحالي ليُسترجع إن ضاعت الحزمة السابقة
                val p = prev
                if (p != null && len == FRAME * 2 && liveDirect() <= MAX_RED_PEERS) {
                    System.arraycopy(p, 0, out, o, FRAME * 2)
                    o += FRAME * 2
                }
                System.arraycopy(cur, 0, out, o, len)
                o += len
                sendAudio(out, o)
                prev = if (len == FRAME * 2) cur.copyOf() else null
            }
        } catch (_: Exception) {
        } finally {
            talking = false
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            fx.forEach { try { it.release() } catch (_: Exception) {} }
        }
    }
}
