package com.sada.walkie

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import org.json.JSONArray
import org.json.JSONObject

private const val RC_MIC = 1
private const val RC_NET = 2
private const val RC_SCAN = 3

// اسم الشبكة يُشتق من «رمز الاتصال»: نفس الرمز => نفس الشبكة في كل الأجهزة.
// لذلك لا يحتاج المنضم لبحث ولا لقائمة ولا لكتابة اسم: يكفي أن يكون عنده الرمز.
// (الاسم يجب أن يبدأ بـ DIRECT-xy- ليقبله Wi-Fi Direct)
private const val PREFIX = "DIRECT-sa-SADA-"
private const val DEFAULT_CODE = "88888888"   // الرمز الافتراضي (يمكن تغييره من التطبيق)
// الانضمام المباشر (بدون نافذة موافقة) يُجرَّب أولاً، وإن فشل يُستخدم WifiNetworkSpecifier تلقائياً.
// يتعلّم التطبيق: إن فشل المباشر على هذا الجهاز مرتين رغم وجود المضيف يتوقف عن تجربته.
private const val P2P_JOIN_MS = 9_000L
private const val SPEC_JOIN_MS = 25_000        // مهلة الانضمام عبر نافذة النظام

private fun ssidFor(code: String): String =
    PREFIX + Integer.toHexString(code.hashCode()).uppercase().padStart(8, '0')

class MainActivity : Activity() {
    private lateinit var radio: Radio
    private lateinit var wv: WebView
    private val ui = Handler(Looper.getMainLooper())
    private var hs: WifiManager.LocalOnlyHotspotReservation? = null
    private var p2p: WifiP2pManager? = null
    private var p2pCh: WifiP2pManager.Channel? = null
    @Volatile private var hsInfo = ""
    @Volatile private var mySsid = ssidFor(DEFAULT_CODE)
    @Volatile private var myPass = DEFAULT_CODE

    // حالة الانضمام: WAIT / OK / ERR / LOST / WIFI_OFF   —   المرحلة: FIND (بحث مباشر) / SYS (نافذة النظام)
    @Volatile private var joinState = ""
    @Volatile private var joinStage = ""
    @Volatile private var joinGen = 0
    private var joinCb: ConnectivityManager.NetworkCallback? = null
    private var p2pJoined = false
    @Volatile private var directJoin = true
    @Volatile private var p2pPendingFail = false
    private val prefs by lazy { getSharedPreferences("sada_net", Context.MODE_PRIVATE) }
    @Volatile private var volPtt = true     // أزرار الصوت بالهاتف = زر التحدث
    private var keyHeld = false

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = granted(Manifest.permission.RECORD_AUDIO)
    private fun netPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES
    else Manifest.permission.ACCESS_FINE_LOCATION

    private fun svc() = Intent(this, WalkieService::class.java)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#F93A3A")
        window.navigationBarColor = Color.parseColor("#B3000D")
        volumeControlStream = AudioManager.STREAM_MUSIC   // أزرار الصوت تتحكم بقوة اللاسلكي
        radio = Radio.get(this)
        directJoin = prefs.getBoolean("direct", true)

        wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#D4121B"))
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.setOnLongClickListener { true }
        setContentView(wv)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowContentAccess = false
            setSupportZoom(false)
            textZoom = 100
        }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        val ok = when (rc) {
            RC_MIC -> hasMic()
            RC_NET -> granted(netPerm())
            else -> return
        }
        wv.evaluateJavascript("window.onPerm&&window.onPerm($rc,$ok)", null)
    }

    // ---------- أزرار الصوت = زر التحدث (اضغط باستمرار) ----------
    // ملاحظة: أندرويد لا يسمح لأي تطبيق باعتراض زر الإطفاء/التشغيل، لذلك نستخدم زري الصوت.
    private fun isVol(c: Int) = c == KeyEvent.KEYCODE_VOLUME_DOWN || c == KeyEvent.KEYCODE_VOLUME_UP

    override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
        if (volPtt && radio.running && isVol(code)) {
            if (e.repeatCount == 0 && !keyHeld) {
                keyHeld = true
                wv.evaluateJavascript("window.onKeyPtt&&window.onKeyPtt(true)", null)
            }
            return true
        }
        return super.onKeyDown(code, e)
    }

    override fun onKeyUp(code: Int, e: KeyEvent): Boolean {
        if (keyHeld && isVol(code)) {
            keyHeld = false
            wv.evaluateJavascript("window.onKeyPtt&&window.onKeyPtt(false)", null)
            return true
        }
        return super.onKeyUp(code, e)
    }

    // نتيجة الماسح: النص يصل للواجهة فتتصل فوراً
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc != RC_SCAN) return
        val t = if (res == RESULT_OK) data?.getStringExtra(ScanActivity.EXTRA_TEXT) else null
        val err = data?.getStringExtra(ScanActivity.EXTRA_ERR) ?: ""
        wv.evaluateJavascript(
            "window.onQr&&window.onQr(" + (if (t == null) "null" else JSONObject.quote(t)) + "," + JSONObject.quote(err) + ")",
            null
        )
    }

    // زر الرجوع: يغلق النافذة المفتوحة، وإلا يُبقي التطبيق يعمل بالخلفية
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        wv.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');if(s&&!s.hidden){s.hidden=true;return 1}return 0})()"
        ) { r -> if (r != "1") moveTaskToBack(true) }
    }

    override fun onDestroy() {
        if (isFinishing) {
            radio.stop()
            stopService(svc())
            stopHost()
            leaveNetwork()
        }
        super.onDestroy()
    }

    // ---------- أدوات Wi-Fi Direct ----------

    private fun p2pMgr(): WifiP2pManager? {
        p2p?.let { return it }
        val m = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager ?: return null
        p2p = m
        return m
    }

    private fun p2pChan(): WifiP2pManager.Channel? {
        p2pCh?.let { return it }
        val m = p2pMgr() ?: return null
        val c = m.initialize(this, Looper.getMainLooper(), null) ?: return null
        p2pCh = c
        return c
    }

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (_: Exception) { true }

    // ---------- المضيف: شبكة ثابتة (Wi-Fi Direct) مع بديل هوتسبوت عشوائي ----------

    private fun info(ssid: String?, pass: String?, fixed: Boolean) {
        hsInfo = JSONObject().put("ssid", ssid ?: "").put("pass", pass ?: "").put("fixed", fixed).toString()
    }

    private fun stopHost() {
        try { hs?.close() } catch (_: Exception) {}
        hs = null
        val m = p2p; val ch = p2pCh
        if (m != null && ch != null) try { m.removeGroup(ch, null) } catch (_: Exception) {}
        hsInfo = ""
    }

    /** يزيل أي مجموعة قديمة أولاً ثم ينشئ الشبكة (بدون الاعتماد على نجاح الإزالة). */
    private fun startHost() {
        hsInfo = ""
        cleanupJoin()
        try { hs?.close() } catch (_: Exception) {}
        hs = null
        val m = p2pMgr(); val ch = p2pChan()
        if (Build.VERSION.SDK_INT < 29 || m == null || ch == null) { startLocalOnly(); return }
        var went = false
        val go = {
            if (!went) {
                went = true
                if (!startDirect(true)) startLocalOnly()
            }
        }
        try {
            m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { ui.postDelayed({ go() }, 400) }
                override fun onFailure(reason: Int) { go() }
            })
            ui.postDelayed({ go() }, 2500)
        } catch (_: Exception) { go() }
    }

    @SuppressLint("MissingPermission")
    private fun startDirect(retry: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val m = p2pMgr() ?: return false
            val ch = p2pChan() ?: return false
            val cfg = WifiP2pConfig.Builder()
                .setNetworkName(mySsid)
                .setPassphrase(myPass)
                .enablePersistentMode(false)
                .build()
            m.createGroup(ch, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { info(mySsid, myPass, true) }
                override fun onFailure(reason: Int) {
                    if (reason == WifiP2pManager.BUSY && retry) {
                        // توجد مجموعة قديمة: أزلها ثم أعد المحاولة مرة واحدة
                        m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                            override fun onSuccess() { ui.postDelayed({ if (!startDirect(false)) startLocalOnly() }, 500) }
                            override fun onFailure(r: Int) { startLocalOnly() }
                        })
                    } else startLocalOnly()
                }
            })
            true
        } catch (_: Exception) { false }
    }

    @SuppressLint("MissingPermission")
    private fun startLocalOnly() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    hs = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration; info(c.ssid, c.passphrase, false)
                    } else {
                        @Suppress("DEPRECATION")
                        val c = r.wifiConfiguration; info(c?.SSID, c?.preSharedKey, false)
                    }
                }
                override fun onFailed(reason: Int) { hsInfo = "ERR:$reason" }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { hsInfo = "ERR:" + e.message }
    }

    // ---------- الانضمام ----------
    // الطريقة 1 (الأسرع، بدون أي نافذة): الانضمام المباشر لمجموعة Wi-Fi Direct بالاسم والرمز.
    // الطريقة 2 (احتياطي): WifiNetworkSpecifier، وتظهر معها نافذة موافقة من أندرويد.

    private fun cleanupJoin() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
        joinCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        joinCb = null
        val m = p2p; val ch = p2pCh
        if (m != null && ch != null) {
            try { m.cancelConnect(ch, null) } catch (_: Exception) {}
            if (p2pJoined) try { m.removeGroup(ch, null) } catch (_: Exception) {}
        }
        p2pJoined = false
    }

    private fun leaveNetwork() {
        joinGen++
        cleanupJoin()
        joinState = ""
        joinStage = ""
    }

    private fun startJoin(ssid: String, pass: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        if (!granted(netPerm())) {
            runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) }
            return false
        }
        val g = ++joinGen
        p2pPendingFail = false
        if (!wifiOn()) { joinState = "WIFI_OFF"; joinStage = ""; return true }
        joinState = "WAIT"
        val viaP2p = directJoin && ssid.startsWith("DIRECT-") &&
            (prefs.getBoolean("p2pOk", false) || prefs.getInt("p2pFail", 0) < 2)
        joinStage = if (viaP2p) "FIND" else "SYS"
        runOnUiThread {
            if (g != joinGen) return@runOnUiThread
            cleanupJoin()
            if (viaP2p) {
                joinViaP2p(ssid, pass, g) { ok ->
                    if (g != joinGen) return@joinViaP2p
                    if (ok) {
                        p2pJoined = true
                        joinState = "OK"
                        prefs.edit().putBoolean("p2pOk", true).putInt("p2pFail", 0).apply()
                        watchP2p(ssid, g)
                    } else {
                        p2pPendingFail = true     // يُحتسب فشلاً فقط إن نجح البديل (أي أن المضيف كان موجوداً)
                        joinViaSpecifier(ssid, pass, g)
                    }
                }
            } else joinViaSpecifier(ssid, pass, g)
        }
        return true
    }

    @SuppressLint("MissingPermission")
    private fun joinViaP2p(ssid: String, pass: String, g: Int, done: (Boolean) -> Unit) {
        val m = p2pMgr(); val ch = p2pChan()
        if (m == null || ch == null) { done(false); return }
        val cfg = try {
            WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).enablePersistentMode(false).build()
        } catch (_: Exception) { done(false); return }
        var fin = false
        val finish = { ok: Boolean ->
            if (!fin) {
                fin = true
                done(ok)
            }
        }
        var started = false
        val go = {
            if (!started && g == joinGen) {
                started = true
                val t0 = SystemClock.elapsedRealtime()
                try {
                    m.connect(ch, cfg, object : WifiP2pManager.ActionListener {
                        override fun onSuccess() {}
                        override fun onFailure(reason: Int) { if (g == joinGen) finish(false) }
                    })
                } catch (_: Exception) { finish(false) }
                val tick = object : Runnable {
                    override fun run() {
                        if (fin || g != joinGen) return
                        try {
                            m.requestGroupInfo(ch) { grp ->
                                if (!fin && g == joinGen) {
                                    if (grp != null && !grp.isGroupOwner && grp.networkName == ssid) finish(true)
                                    else if (SystemClock.elapsedRealtime() - t0 > P2P_JOIN_MS) finish(false)
                                    else ui.postDelayed(this, 500)
                                }
                            }
                        } catch (_: Exception) { finish(false) }
                    }
                }
                ui.postDelayed(tick, 1000)
            }
        }
        // نظّف أي محاولة/مجموعة سابقة ثم اتصل (مع مهلة أمان إن لم يصل رد النظام)
        try {
            m.cancelConnect(ch, null)
            m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { ui.postDelayed({ go() }, 300) }
                override fun onFailure(reason: Int) { go() }
            })
        } catch (_: Exception) {}
        ui.postDelayed({ go() }, 1500)
    }

    /** يراقب الاتصال المباشر: إن اختفت المجموعة (انقطع المضيف) تصبح الحالة LOST فتعيد الواجهة الاتصال. */
    private fun watchP2p(ssid: String, g: Int) {
        val m = p2p ?: return
        val ch = p2pCh ?: return
        val tick = object : Runnable {
            override fun run() {
                if (g != joinGen || joinState != "OK") return
                try {
                    m.requestGroupInfo(ch) { grp ->
                        if (g == joinGen) {
                            if (grp == null || grp.networkName != ssid) joinState = "LOST"
                            else ui.postDelayed(this, 2000)
                        }
                    }
                } catch (_: Exception) {}
            }
        }
        ui.postDelayed(tick, 2000)
    }

    private fun joinViaSpecifier(ssid: String, pass: String, g: Int) {
        if (g != joinGen) return
        joinStage = "SYS"
        p2p?.let { m -> p2pCh?.let { ch -> try { m.cancelConnect(ch, null) } catch (_: Exception) {} } }
        val spec = try {
            WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
        } catch (_: Exception) { joinState = "ERR"; return }
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var target: Network? = null
        // الربط بالشبكة قد يفشل لحظة ظهورها، فنعيد المحاولة مع كل تحديث بدل اعتباره فشلاً
        fun attach(n: Network) {
            if (g != joinGen) return
            if (joinState == "OK" && target == n) return
            if (cm.bindProcessToNetwork(n)) {
                target = n
                joinState = "OK"
                if (p2pPendingFail) {
                    p2pPendingFail = false
                    prefs.edit().putInt("p2pFail", prefs.getInt("p2pFail", 0) + 1).apply()
                }
                if (radio.running) radio.restart()      // إعادة ربط المقبس بالشبكة الجديدة
            }
        }
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) { attach(n) }
            override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) { attach(n) }
            override fun onLinkPropertiesChanged(n: Network, lp: android.net.LinkProperties) { attach(n) }
            override fun onUnavailable() {
                if (g != joinGen) return
                try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
                joinState = "ERR"
            }
            override fun onLost(n: Network) {
                if (g != joinGen) return
                try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
                target = null
                joinState = "LOST"
                if (radio.running) radio.restart()
            }
        }
        joinCb = cb
        try { cm.requestNetwork(req, cb, SPEC_JOIN_MS) } catch (_: Exception) { joinState = "ERR" }
    }

    inner class Bridge {
        // ---------- التشغيل ----------
        @JavascriptInterface fun hasMic(): Boolean = this@MainActivity.hasMic()
        @JavascriptInterface fun hasNetPerm(): Boolean = granted(netPerm())
        @JavascriptInterface fun reqNetPerm() { runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) } }

        @JavascriptInterface fun start(): Boolean {
            if (!this@MainActivity.hasMic()) {
                val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
                    list.add(Manifest.permission.POST_NOTIFICATIONS)
                runOnUiThread { requestPermissions(list.toTypedArray(), RC_MIC) }
                return false
            }
            val ok = radio.start()
            if (ok) runOnUiThread { try { startForegroundService(svc()) } catch (_: Exception) {} }
            return ok
        }

        @JavascriptInterface fun stop() {
            radio.stop()
            runOnUiThread { stopService(svc()) }
        }

        @JavascriptInterface fun running(): Boolean = radio.running
        @JavascriptInterface fun talk(on: Boolean) = radio.talk(on)
        @JavascriptInterface fun peers(): Int = radio.peers()
        @JavascriptInterface fun receiving(): Boolean = System.currentTimeMillis() - radio.lastRx < 500
        @JavascriptInterface fun setChannel(c: Int) { radio.channel = c.coerceIn(1, 8) }
        @JavascriptInterface fun setListen(l: Boolean) { radio.listen = l }
        @JavascriptInterface fun setVolPtt(on: Boolean) { volPtt = on }
        @JavascriptInterface fun setDirectJoin(on: Boolean) {
            if (on != directJoin) {
                directJoin = on
                prefs.edit().putBoolean("direct", on).putInt("p2pFail", 0).apply()
            }
        }

        // ---------- الصوت والشاشة ----------
        @JavascriptInterface fun setBoost(l: Int) { radio.boost = l.coerceIn(0, 3); radio.applyVolume() }
        @JavascriptInterface fun setPhoneAudio(on: Boolean) { radio.phoneAudio = on; radio.applyVolume() }
        @JavascriptInterface fun keepScreen(on: Boolean) = runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        @JavascriptInterface fun haptic() = runOnUiThread {
            wv.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        /** أقصى سطوع أثناء عرض رمز QR (يسهّل المسح)، ثم يعود للسطوع العادي. */
        @JavascriptInterface fun brightness(max: Boolean) = runOnUiThread {
            val lp = window.attributes
            lp.screenBrightness = if (max) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            window.attributes = lp
        }

        // ---------- إنشاء الشبكة (مضيف) ----------
        // النتيجة JSON: {"ssid":..,"pass":..,"fixed":true|false} أو نص يبدأ بـ ERR
        @JavascriptInterface fun hotspotStart(code: String): Boolean {
            if (!granted(netPerm())) {
                runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) }
                return false
            }
            myPass = if (code.length in 8..63) code else DEFAULT_CODE
            mySsid = ssidFor(myPass)
            hsInfo = ""
            if (!wifiOn()) { hsInfo = "ERR:WIFI_OFF"; return true }
            runOnUiThread { startHost() }
            return true
        }
        @JavascriptInterface fun hotspotInfo(): String = hsInfo
        @JavascriptInterface fun hotspotStop() { runOnUiThread { stopHost() } }

        // ---------- الانضمام ----------
        @JavascriptInterface fun defaultCode(): String = DEFAULT_CODE
        @JavascriptInterface fun roomSsid(code: String): String =
            ssidFor(if (code.length in 8..63) code else DEFAULT_CODE)

        /** انضمام فوري لشبكة الرمز: بلا بحث ولا قائمة. */
        @JavascriptInterface fun joinRoom(code: String): Boolean {
            val c = if (code.length in 8..63) code else DEFAULT_CODE
            return startJoin(ssidFor(c), c)
        }

        /** اتصال بشبكة محددة (من QR أو يدوياً). */
        @JavascriptInterface fun join(ssid: String, pass: String): Boolean = startJoin(ssid, pass)

        @JavascriptInterface fun joinState(): String = joinState
        @JavascriptInterface fun joinStage(): String = joinStage
        @JavascriptInterface fun leaveNetwork() = this@MainActivity.leaveNetwork()

        /** البحث عن شبكات قريبة (للاتصال اليدوي فقط): JSON [{"ssid":..,"level":..}] */
        @SuppressLint("MissingPermission")
        @JavascriptInterface fun scanNetworks(all: Boolean): String {
            if (!granted(netPerm())) return "[]"
            val arr = JSONArray()
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                try { wm.startScan() } catch (_: Exception) {}
                val best = HashMap<String, Int>()
                @Suppress("DEPRECATION")
                for (r in wm.scanResults) {
                    val n = r.SSID ?: continue
                    if (n.isEmpty()) continue
                    if (!all && !n.startsWith(PREFIX)) continue
                    val lv = WifiManager.calculateSignalLevel(r.level, 4)
                    if (lv > (best[n] ?: -1)) best[n] = lv
                }
                for (e in best.entries.sortedByDescending { it.value })
                    arr.put(JSONObject().put("ssid", e.key).put("level", e.value))
            } catch (_: Exception) {}
            return arr.toString()
        }

        /** رسم رمز QR: أسطر من 0/1 مفصولة بسطر جديد (بدون هامش؛ الواجهة ترسم الهامش الأبيض). */
        @JavascriptInterface fun qrMatrix(text: String): String = try {
            val hints = mapOf<EncodeHintType, Any>(
                EncodeHintType.MARGIN to 0,
                EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M
            )
            val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 1, 1, hints)
            val sb = StringBuilder()
            for (y in 0 until m.height) {
                for (x in 0 until m.width) sb.append(if (m.get(x, y)) '1' else '0')
                sb.append('\n')
            }
            sb.toString()
        } catch (_: Exception) { "" }

        /** يفتح شاشة المسح (فيها خيار إدخال الرمز يدوياً)؛ النتيجة تصل عبر window.onQr(text|null, err). */
        @JavascriptInterface fun scanQr(code: String) {
            runOnUiThread {
                try {
                    startActivityForResult(
                        Intent(this@MainActivity, ScanActivity::class.java).putExtra(ScanActivity.EXTRA_CODE, code),
                        RC_SCAN
                    )
                } catch (_: Exception) {
                    wv.evaluateJavascript("window.onQr&&window.onQr(null,'camera')", null)
                }
            }
        }
    }
}
