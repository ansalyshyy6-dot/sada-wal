plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sada.walkie"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sada.walkie"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "2.6"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // ماسح QR مدمج داخل التطبيق (يعمل بدون إنترنت وبدون خدمات Google Play)
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("androidx.activity:activity:1.8.2")
    // توليد رمز QR
    implementation("com.google.zxing:core:3.5.3")
}
